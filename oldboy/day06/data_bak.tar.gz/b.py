#!/usr/bin/python
# -*- coding:utf-8 -*-


print('from b')