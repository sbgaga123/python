#!/usr/bin/python
# -*- coding:utf-8 -*-

# print('spam')
# import sys
# print('在b。py中看见的sys.path',sys.path)
# sys.path.append(r'E:\wupeiqi\s17\day06\bbb')
# import b

# from bbb import b #E:\wupeiqi\s17\day06\bbb\b.py

# from . import b



import os,sys
# print(os.path.abspath(__file__))

# BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# sys.path.append(BASE_DIR)

# E:/wupeiqi/s17/day06/bbb/spam.py/../..
# BASE_DIR=os.path.normpath(os.path.join(__file__,
#              os.pardir,
#              os.pardir)
# )
# print(BASE_DIR)